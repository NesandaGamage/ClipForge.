# ClipForge — Android video clipper

ClipForge is a native Kotlin Android Studio project. It imports a video from device storage, trims a segment by start/end seconds, encodes H.264/AAC MP4, and saves it to `Movies/ClipForge`.

## Important YouTube limitation
The YouTube URL field opens the video in the YouTube app/browser. YouTube does not offer a general-purpose API that lets third-party apps download arbitrary videos as MP4. To edit a YouTube video, import an MP4 you own or are authorized to use (for example, an export of your own upload from YouTube Studio). This project intentionally does not scrape YouTube streams or bypass access controls.

## Build
1. Install Android Studio (Koala or newer) and Android SDK Platform 35.
2. Open this folder in Android Studio.
3. Let Gradle sync. Use JDK 17.
4. Connect an Android phone with USB debugging enabled, or create an emulator.
5. Press **Run**. To create an APK, choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

## Use
1. Paste a YouTube link and tap **Open YouTube video** (optional).
2. Tap **Import video from phone** and choose an MP4/video you can lawfully use.
3. Enter start and end times in seconds (e.g. 35 and 58).
4. Tap **Export MP4**. The result is saved under Movies/ClipForge.

## Current scope / known limitations
- Single clip per export; repeat to create additional clips.
- The resolution and aspect-ratio controls are currently UI placeholders; export uses the source dimensions and preserves its aspect ratio.
- The trim is performed by Media3 Transformer. Some source formats may require extra processing time.
- Keep the app open during export in this starter build.
- The app requires Android 8.0 (API 26) or newer.

## Project structure
- `app/src/main/java/com/clipforge/app/MainActivity.kt` — app UI and trim/export pipeline.
- `app/src/main/AndroidManifest.xml` — app declaration.


## Build an APK automatically with GitHub Actions
This repository includes `.github/workflows/build-apk.yml`.

1. Create a new **public or private** GitHub repository (for example `ClipForge`).
2. Upload/push the complete contents of this project folder to the repository's `main` branch. Include the hidden `.github` folder.
3. On GitHub, open **Actions** and enable workflows if prompted.
4. Select **Build ClipForge APK** and choose **Run workflow** (or push a commit to `main`).
5. When the run completes successfully, open the workflow run, scroll to **Artifacts**, and download `ClipForge-debug-apk`.
6. Extract the downloaded artifact. It contains `app-debug.apk`. Open it on your Pixel 7a and allow installation from the browser/files app if Android asks.

The APK is a debug-signed build intended for personal testing/sideloading. It is not a Play Store release. The workflow has not been run yet; GitHub will compile the project when you push it.

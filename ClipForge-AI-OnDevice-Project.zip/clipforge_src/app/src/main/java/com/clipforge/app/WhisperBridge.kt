package com.clipforge.app

/** JNI bridge to the upstream whisper.cpp inference engine. */
object WhisperBridge {
    init { System.loadLibrary("clipforge_whisper") }
    external fun transcribeNative(modelPath: String, wavPath: String): String
}
